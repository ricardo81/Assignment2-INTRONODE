var express = require('express');
var comments = require('./comments');
var router = express.Router();

let pstore ={}
pstore.posts = []
exports.pstore=pstore;
/*
  posts: [
    {name: 'Top 10 ES6 Features every Web Developer must know',
    url: 'https://webapplog.com/es6',
    text: 'This essay will give you a quick introduction to ES6. If you don’t know what is ES6, it’s a new JavaScript implementation.',
    comments: [
      text: 'Cruel…..var { house, mouse} = No type optimization at all',
      text: 'I think you’re undervaluing the benefit of ‘let’ and ‘const’.',
      text: '(p1,p2)=>{ … } ,i understand this ,thank you !'      
    ]
    }
  ]
  */

router.get('/posts', function (req, res) {
  res.status(200).send(pstore.posts)
  console.log("Got all Posts");
})  
  
router.post('/posts', function (req, res) {
  let newPost = req.body
  let postid = pstore.posts.length
  pstore.posts.push(newPost)
  res.status(201).send({postid: postid})
	console.log("Added a Post");
})

router.put('/posts/:postid', function (req, res) {
  pstore.posts[req.params.postid] = req.body
  res.status(200).send(pstore.posts[req.params.postid])
  console.log("Added Post with Id: "+req.params.postid);
})  
  
router.delete('/posts/:postid', function (req, res) {
	  pstore.posts.splice(req.params.postid, 1)
	  res.status(204).send()
})


  
module.exports = router
/*
module.exports = {
  getPosts(req, res) {
	console.log("Got Posts");
  },

  },
  updatePost(req, res) {
	console.log("Updated Posts");
  },
  removePost(req, res) {
	console.log("Removed Posts");
  }
}
*/

