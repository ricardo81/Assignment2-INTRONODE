var express = require('express');
var post = require('./posts.js');
var router = express.Router();

/*
  posts: [
    {name: 'Top 10 ES6 Features every Web Developer must know',
    url: 'https://webapplog.com/es6',
    text: 'This essay will give you a quick introduction to ES6. If you don’t know what is ES6, it’s a new JavaScript implementation.',
    comments: [
      text: 'Cruel…..var { house, mouse} = No type optimization at all',
      text: 'I think you’re undervaluing the benefit of ‘let’ and ‘const’.',
      text: '(p1,p2)=>{ … } ,i understand this ,thank you !'      
    ]
    }
  ]
  */

router.get('/posts/:postid/comments', function (req, res) {
	let commentid = req.params.postid
	let compstore = post.pstore.posts[commentid];
	if(compstore)
	{
		res.status(200).send(compstore.comments)
	}else
	{
		res.status(404).send()
	}
	console.log("Got all Comments for post: "+commentid);
})   
  
router.post('/posts/:postid/comments', function (req, res) {
	let newcomment = req.body
	let postid = req.params.postid
	let compstore = post.pstore.posts[postid]
	let commentid = 0
	
	if(compstore.comments)
	{
		compstore.comments.push(newcomment)
		commentid=compstore.comments.length-1
	}else
	{
		compstore.comments=[]
		compstore.comments.push(newcomment)
		commentid=compstore.comments.length-1
	}
	res.status(201).send({commentid: commentid})
	console.log("Added a comment (id: "+commentid+") for post: "+commentid);
})  
  
router.put('/posts/:postid/comments/:commentid', function (req, res) {
	let upcomment = req.body
	let postid = req.params.postid
	let newcommentid = req.params.commentid
	let compstore = post.pstore.posts[postid]
	
	if(compstore.comments)
	{
		compstore.comments[newcommentid]=upcomment
		res.status(200).send({newcommentid:newcommentid})
		console.log("Updated comment with id: "+postid+" for post: "+newcommentid);
	}


})  
  
router.delete('/posts/:postid/comments/:commentid', function (req, res) {
	let postid = req.params.postid
	let commentid = req.params.commentid
	let compstore = post.pstore.posts[postid]
	
	if(compstore.comments)
	{
		compstore.comments.splice(commentid,1)
		res.status(204).send()
		console.log("Deleted all comments for Post with Id: "+postid)
	}
})

module.exports = router